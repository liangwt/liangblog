$(function(){
	$('article').readmore({
        speed: 2000,
        maxHeight: 500,
        moreLink:'<a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>'
	});
})