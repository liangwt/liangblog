/*$(function(){
	$(".version>.row:odd").each(function(){
		$(this).addClass("tm-flex-container-reverse");
		$(this).children("#icon").addClass("tm-flex-child-2");
		$(this).children("#vcontent").addClass("tm-flex-child-1");
	})
})*/