## LiangBlog简介

此博客采用ThinkPHP开发，使用了以下插件

* 主题模板采用了Bootstarp 
* 文章输入框使用了 wangEditer
* 文件上传使用了 uploadify
* 文本框多标签输入使用了 Tagsinput
* 时间输入使用了datatimepicker
* 通知使用了toastr
