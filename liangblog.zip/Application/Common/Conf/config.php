<?php
return array(
	//'配置项'=>'配置值'
	'DB_HOST'	 => 'bdm186320493.my3w.com',
	'DB_TYPE'    => 'mysql',
	'DB_NAME'    => 'bdm186320493_db',
	'DB_USER'    => 'bdm186320493',
	'DB_PWD'     => '369125255L',
/*	'DB_TYPE'    => 'mysql',
	'DB_NAME'    => 'liangblog',
	'DB_USER'    => 'root',
	'DB_PWD'     => '',*/

	'DB_PORT'    => '3306',
	'DB_PREFIX'  => 'blog_',
	'DB_CHARSET' => 'utf8',   
	//调试信息
/*	'SHOW_PAGE_TRACE' =>true,  */
	//错误信息
	'ERROR_PAGE' =>__ROOT__.'/Public/404/error.html'
);