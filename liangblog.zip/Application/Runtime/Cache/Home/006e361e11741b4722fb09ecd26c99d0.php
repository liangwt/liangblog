<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>文章</title>

    <!-- Bootstrap -->
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/liangblog/Public/bootstrap/css/bootstrap.min.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
    <link href="/liangblog/Public/bootstrap/css/blog-home.css" rel="stylesheet">


    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <link href="http://cdn.bootcss.com/toastr.js/latest/toastr.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/toastr.js/latest/toastr.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="/liangblog/Public/bootstrap/js/bootstrap.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="stylesheet" type="text/css" href="/liangblog/Public/highlightJS/styles/atelier-cave.dark.css">
<link rel="stylesheet" type="text/css" href="/liangblog/Public/SweetAlert/dist/sweetalert2.css">
<script src="/liangblog/Public/SweetAlert/dist/sweetalert2.js"></script>
<script type="text/javascript" src="/liangblog/Public/goup/goup.js"></script>

<script type="text/javascript" src="/liangblog/Public/Js/detailArticle.js"></script>
<script type="text/javascript">
    var showArticle = "<?php echo U('Article/showArticle');?>"; 
    var commentUrl = "<?php echo U('Article/saveComment');?>";
    var deleteUrl = "<?php echo U('Article/deleteArticle');?>?id=<?php echo ($list["id"]); ?>";
</script>
<script type="text/javascript">
  var registerurl = "<?php echo U('Home/login/register');?>";
  var loginurl = "<?php echo U('Home/login/login');?>";
  var logouturl = "<?php echo U('Home/login/logout');?>";
  var goup = "/liangblog/Public/image/nav/up.png";
</script>
<script type="text/javascript" src="/liangblog/Public/Js/nav.js"></script>
<link rel="stylesheet" type="text/css" href="/liangblog/Public/goup/goup.css">

</head>
<!--login model -->

<body>

<div class="actGotop"><image src="/liangblog/Public/image/nav/up.png" id="Top"></image></div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">登陆</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="account">账户</label> 
          <input type="text" name="account" class="form-control" id="login_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="login_password">密码</label>
          <input type="password" name="password" class="form-control" id="login_password" placeholder="密码">
        </div>

        <div class="form-group">
          <label for="login_code">验证码</label>
          <input type="text" name="password" id="login_code" class="form-control" placeholder="验证码">
        </div>
        <div class="form-group">
        <image src="<?php echo U('Home/login/verifyCode');?>" id="verifyCode">
        </div>        
        <div class="form-group">
          <label>
            <input type="checkbox" name="auto" id="auto_login" value="1"> 自动登录
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#register">没有账号？点击注册</a></div>
        <button type="button" id="btn_login" class="btn btn-success" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;&nbsp;登陆</button>
      </div>
    </div>
  </div>
</div>

<!--register model -->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">注册</h4>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="register_account">账户</label>
          <input type="text" name="account" class="form-control" id="register_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="register_password">密码</label>
          <input type="password" name="password" class="form-control" id="register_password" placeholder="密码">
        </div>
        <div class="form-group">
          <label for="register_rpassword">重复密码</label>
          <input type="password" name="rpassword" class="form-control" id="register_rpassword" placeholder="重复密码">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default right" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <button type="button" id="btn_register" class="btn btn-primary" data-dismiss="modal"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;注册</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#login">已有账号？点击登陆</a></div>
      </div>
    </div>
  </div>
</div> 
 
<!--nav -->
<div class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">liangblog</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo U('Home/Article/showArticle');?>">博客</a></li>
                <li><a href="http://resume.qmail.com/liang.w.t/351hjrDgthw">简历</a></li>
                <li><a href="<?php echo U('Home/About/about');?>">关于</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!isset($_SESSION['uid'])): ?><li><a href="#" data-toggle="modal" data-target="#register">注册</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login">登陆</a></li>
                <?php else: ?>
                    <a class="navbar-brand personPhoto" href="#">
                      <img class="media-object" src="http://placehold.it/64x64" alt="" style="width: 30px;height: 30px;border-radius:50%">
                    </a>

                    <p class="navbar-text"><?php echo (session('username')); ?></p>

                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">个人中心<strong class="caret"></strong></a>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="<?php echo U('Article/writeArticle');?>">发布博客</a>
                        </li>
                        <li>
                          <a href="<?php echo U('user/editBasic');?>">修改个人信息</a>
                        </li>
                        <li>
                          <a href="#">消息中心</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                          <a id="logout" href="#">退出登录</a>
                        </li>
                      </ul>
                    </li><?php endif; ?>
            </ul>
        </div>  
    </div>    
</div>








<div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="blog-post">
                    <h2 class="blog-post-title"><a href="<?php echo U('Article/detailArticle');?>?id=<?php echo ($list["id"]); ?>"><?php echo ($list["title"]); ?></a></h2>

                    <p class="blog-post-meta"><?php echo (date("F d",strtotime($list["create_time"]))); ?> by <a href="<?php echo U('Resume/resume');?>?id=<?php echo ($list["uid"]); ?>"><?php echo ($list["username"]); ?></a>
                    <a class="pull-right" href="<?php echo U('Article/editArticle');?>?id=<?php echo ($list["id"]); ?>">编辑</a>
                    
                    <a class="pull-right" href="" id="deleteArticle">删除&nbsp;&nbsp;&nbsp;</a>
                    </p>

                    <p class="blog-post-meta">
                        <?php if(is_array($tags)): foreach($tags as $key=>$t): ?><span class="label"><?php echo (trim($t["name"])); ?></span>&nbsp;<?php endforeach; endif; ?>                    
                    </p> 

                    <hr>
                    <p><?php echo (htmlspecialchars_decode($list["content"])); ?></p>
                </div>
                <!--commoentInput-->
                <br>
                <br>
                <br>
                <form role="form" id="comment">
                    <legend>发布评论</legend>
                        <div class="form-group">
                            <label for="username">用户名</label>
                            <input type="text" class="form-control" name="username" placeholder="Enter username">
                        </div>
                        <div class="form-group">
                            <label for="comment">输入评论</label>
                            <textarea class="form-control" rows="3" name="comment_text"></textarea>
                        </div>
                        <input type="hidden" value="<?php echo ($list["id"]); ?>" name="article_id">
                        <button type="button" class="btn btn-success" id="sub_comment">Submit</button>
                </form>
                <br>
                <br>
                <br>
                <!-- Comment -->
                <div>
                <?php if(is_array($comment)): foreach($comment as $key=>$c): ?><div class="media">
                    <a class="pull-left" href="#">
                        <img class="media-object" src="http://placehold.it/64x64" alt="" style="width: 50px;height: 50px;border-radius:50%">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading">                    
                            <?php if($c["uid"] == 0): ?>匿名用户
                            <?php else: ?>
                                <?php echo ($c["uid"]); endif; ?>
                            <small>August 25, 2014 at 9:30 PM</small>
                        </h4>
                        <input type="hidden" name="commentId" value={c.id}>
                        <?php echo ($c["content"]); ?>
                        <br/>
                        <div>
                            <span class="glyphicon glyphicon-chevron-up" style="cursor:pointer;"></span> 100&nbsp;|
                            <span class="glyphicon glyphicon-chevron-down"style="cursor:pointer;"></span> 100&nbsp;|
                            <span class="glyphicon glyphicon-edit"></span> 回复      
                        </div>
                        
                        <?php if(is_array($c["secondComment"])): foreach($c["secondComment"] as $key=>$s): ?><!-- Nested Comment -->
                        <div class="media">
                            <a class="pull-left" href="#">
                                <img class="media-object" src="http://placehold.it/64x64" alt="" style="width: 50px;height: 50px;border-radius:50%">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading">
                                    <?php if($s["uid"] == 0): ?>匿名用户
                                    <?php else: ?>
                                        <?php echo ($s["uid"]); endif; ?><small>回复了</small><?php echo ($s["comment_pid"]); ?>
                                    <small>August 25, 2014 at 9:30 PM</small>
                                </h4>
                                <input type="hidden" name="commentId" value={c.id}>
                                <?php echo ($s["content"]); ?>
                            </div>
                        </div>
                        <!-- End Nested Comment --><?php endforeach; endif; ?>
                    </div>
                </div><?php endforeach; endif; ?>
                </div>
            </div>
        </div>
        <div class="row  text-center">
    <footer class="col-md-12 ">
        <p class="tm-text-white tm-copyright-text"><a class="copyright" target="_blank" href="https://my.oschina.net/liangwt/blog">Copyright &copy; 2016.Company name All rights reserved.</a></p>
    </footer>
</div>
</div>
</body>
</html>