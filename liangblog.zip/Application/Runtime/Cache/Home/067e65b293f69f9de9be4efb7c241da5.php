<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>首页</title>

    <!-- Bootstrap -->
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/liangblog/Public/bootstrap/css/bootstrap.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
 


    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <link href="http://cdn.bootcss.com/toastr.js/latest/toastr.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/toastr.js/latest/toastr.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="/liangblog/Public/bootstrap/js/bootstrap.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

  <meta charset="UTF-8">
  <title>Terry的响应式个人简历 - GBtags.com</title>
  <style>

	/* 定义辅助CSS来美化简历头部 */
	body{
	  font-family: 'microsoft yahei',Arial,sans-serif;
	}

	.cvheader{
	  border-bottom: 1px solid #DFDFDF;
	  padding-top:30px;
	  padding-bottom:20px;
	}

	.cvheader h1{
	  margin:0;
	}

	.address{
	  background: #efb73e;
	  color: #fff;
	  padding: 10px 0;
	}

	/* 定义辅助CSS来美化简历主体 */

	.cvbody{
	  padding-top: 50px; 
	}

	.cbox{
	  margin-bottom: 30px;
	  color: #FFF;
	  padding: 50px;
	}

	/* 定义cbox颜色 */
	.green{
	  background: #2ecc71;
	}

	.orange{
	  background: orange;
	}

	.red{
	  background: #dd4814;
	}

	.bbox{
	  border: 1px solid #DFDFDF;
	  border-radius: 5px;
	  margin-bottom:30px;
	  padding: 50px;
	}

	.footer{
	  margin: 30px 0 30px;
	  padding: 50px;
	  background: #CCC;
	  color: #FFF;
	}
</style>

<script type="text/javascript">
  var registerurl = "<?php echo U('login/register');?>";
  var loginurl = "<?php echo U('login/login');?>";
  var logouturl = "<?php echo U('login/logout');?>";
</script>
<script type="text/javascript" src="/liangblog/Public/Js/nav.js"></script>
<style type="text/css">
.actGotop{
    position:fixed; 
    _position:absolute; 
    bottom:10px; 
    right:90px; 
    display:none;
}
#Top{
    width:70px; 
    height:61px; 
}
.top_text{
  text-align: center;
}
</style>
<script type="text/javascript">
$(function(){ 
  $(window).scroll(function() {   
    if($(window).scrollTop() >= 100){
      $('.actGotop').fadeIn(300); 
    }else{    
      $('.actGotop').fadeOut(300);    
    }  
  });
  $('.actGotop').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);}); 
});
</script>

</head>
<!--login model -->

<body>

<div class="actGotop"><image src="/liangblog/Public/image/nav/up.png" id="Top"><p class="top_text">返回顶部</p></image></div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">登陆</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="account">账户</label> 
          <input type="text" name="account" class="form-control" id="login_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="login_password">密码</label>
          <input type="password" name="password" class="form-control" id="login_password" placeholder="密码">
        </div>
        <br/>
        <div class="form-group">
          <label>
            <input type="checkbox" name="auto" id="auto_login" value="1"> 自动登录
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#register">没有账号？点击注册</a></div>
        <button type="button" id="btn_login" class="btn btn-success" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;&nbsp;登陆</button>
      </div>
    </div>
  </div>
</div>

<!--register model -->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">注册</h4>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="register_account">账户</label>
          <input type="text" name="account" class="form-control" id="register_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="register_password">密码</label>
          <input type="password" name="password" class="form-control" id="register_password" placeholder="密码">
        </div>
        <div class="form-group">
          <label for="register_rpassword">重复密码</label>
          <input type="password" name="rpassword" class="form-control" id="register_rpassword" placeholder="重复密码">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default right" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <button type="button" id="btn_register" class="btn btn-primary" data-dismiss="modal"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;注册</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#login">已有账号？点击登陆</a></div>
      </div>
    </div>
  </div>
</div>

<!--nav -->
<div class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo U('Index/index');?>">liangblog</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo U('Article/showArticle');?>">博客</a></li>
                <li><a href="<?php echo U('resume/resume');?>">简历</a></li>
                <li><a href="<?php echo U('About/about');?>">关于</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!isset($_SESSION['uid'])): ?><li><a href="#" data-toggle="modal" data-target="#register">注册</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login">登陆</a></li>
                <?php else: ?>

                    <p class="navbar-text"><?php echo (session('username')); ?></p>

                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">个人中心<strong class="caret"></strong></a>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="<?php echo U('Article/writeArticle');?>">发布博客</a>
                        </li>
                        <li>
                          <a href="<?php echo U('user/editBasic');?>">修改个人信息</a>
                        </li>
                        <li>
                          <a href="#">消息中心</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                          <a id="logout" href="#">退出登录</a>
                        </li>
                      </ul>
                    </li><?php endif; ?>
            </ul>
        </div>  
    </div>    
</div>







  <!-- 定义简历的头部 //-->

<div class="container">
  <div class="row cvheader">
    <div class="col-lg-7 col-md-8 col-xs-12">
      <!--  添加颜色//-->
      <h1 class="text-primary">Terry Lee</h1>
      <!--  添加图标 //-->
      <p><span class="glyphicon glyphicon-paperclip"></span> 前端工程师 && UI设计师</p>
    </div>
    
    <div class="col-lg-3 col-md-3 col-xs-12">
      <div class="row">
        
        <div class="col-lg-4 col-md-4 col-xs-4">
          <p id="contact" class="address text-center">联系</p>
        </div>
        
        <div class="col-lg-8 col-md-8 col-xs-8">
          <p><span class="glyphicon glyphicon-envelope"></span> terry.lee@gmail.com</p>
          <p><span class="glyphicon glyphicon-earphone"></span> 13901239073</p>
          <p><span class="glyphicon glyphicon-road"></span> 北京市朝阳区劲松三区</p>
        </div>
        
      </div>
    </div>
    
    <div class="col-lg-2 col-md-2 col-xs-12">
      <p>
        <!-- 这里定义图片为响应式，并且添加圆角效果，以便保证图片在不同设备上都可以完美显示 //-->
        <img data-toggle="tooltip" data-placement="left" id="avatar" title="我是Terry" class="img-responsive img-rounded" src="http://www.gbtags.com/gb/networks/avatars/13d6393f-a44c-4180-8cb6-7bf0e4776283.png" alt="">
       </p>
    </div>
  </div>
</div>

<!-- 定义简历的主体部分 //-->

<div class="container">
  <div class="row cvbody">
    
    <!-- 这里定义两个区域，布局定义如下：//-->
    
    <div class="col-lg-6 col-md-8 col-xs-12">
    
      <div class="row">
        <div class="cbox green">
          <h4>个人介绍</h4>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus asperiores eum consequatur hic rem earum repudiandae dicta! Est officiis similique fugiat quod quibusdam rerum ipsum eos soluta tempore cupiditate! Accusantium?
          </p>
        </div>
        <div class="cbox red">
          <h4>个人技能</h4>
          <p>
            <!-- 这里使用Bootstrap3的组件添加技能 //-->
            
            HTML/CSS/Javascript
            <div class="progress">
              <div class="progress-bar progress-bar-success" style="width:80%"></div>
            </div>
            
            Java/J2EE
            <div class="progress">
              <div class="progress-bar progress-bar-primary" style="width:90%"></div>
            </div>
            
            数据库
            <div class="progress">
              <div class="progress-bar progress-bar-info" style="width:80%"></div>
            </div>
            
            Photoshop/UI
            <div class="progress">
              <div class="progress-bar progress-bar-warning" style="width:50%"></div>
            </div>
          </p>
        </div>
        <div class="cbox orange">
          <h4>语言水平</h4>
          <p>
			<canvas id="en" width="150" height="150" class="pull-left"></canvas>
			<canvas id="zh" width="150" height="150" class="pull-right"></canvas>
			<p class="clearfix"></p>
          </p>
        </div>
      </div>
    
    </div>
    
    <!-- 为了清楚的分割两个区域，这里我们添加了一个空白区域，或者也可以在CSS中定义Margin实现//-->
    <div class="col-lg-1 col-md-1 col-xs-12"></div>
    
    <div class="col-lg-5 col-md-5 col-xs-12">
    
      <div class="row">
        <div class="bbox">
          <h4>教育背景</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione enim adipisci minima perspiciatis ad nesciunt iure asperiores voluptatem neque aperiam molestias cupiditate facilis a eveniet iste sapiente ab repellendus dignissimos.</p>
        </div>
        <div class="bbox">
          <h4>工作经验</h4>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis dolorem mollitia repellendus. Magni laudantium placeat repudiandae tempore iure deleniti obcaecati. Architecto delectus doloremque quo. Dicta ratione vero eos pariatur itaque.</p>
        </div>
        <div class="bbox">
          <h4>个人爱好</h4>
          <p>
            <span class="glyphicon glyphicon-tree-deciduous"></span> 骑马
            <span class="glyphicon glyphicon-plane"></span> 旅游
            <p><span class="glyphicon glyphicon-cutlery"></span> 美食</p>
            <p><span class="glyphicon glyphicon-music"></span> 音乐</p>
          </p>
        </div>
      </div>
    
    </div>
    
    
  </div>
</div>

<!-- 定义简历页底 //-->
<div class="container">
  <div class="row"><div class="footer text-center">关注-微博</div></div>
</div>

<script>
/*Javascript源代码*/

$(function(){
  $('#contact').popover({placement:'bottom', container: 'body', html:true, content:'<p>QQ: 36181610</p><p>微博：weibo.com/gbtags</p><p>微信：gbtags</p>'});
  $('#avatar').tooltip({'placement':'bottom'});
  
	$.getScript('http://www.chartjs.org/assets/Chart.js',function(){
	  
	  var zhdata = [{
			label: '中文水平',
			value: 90,
			highlight: "#FFC870",
			color: "#F7464A"
		}, {
			value: 10,
			color: "#EEEEEE"
		}
		]

		var zhoptions = {
			animation: true,
			segmentShowStroke : false
		};

		var c = $('#zh');
		var ct = c.get(0).getContext('2d');
		
		var zhChart = new Chart(ct).Doughnut(zhdata, zhoptions);

	
	  var endata = [{
			label: '英文水平',
			value: 80,
			highlight: "#5AD3D1",
			color: "#4D5360"
		}, {
        value: 20,
        color: "#EEEEEE"
		}
		]

		var enoptions = {
			animation: true,
			segmentShowStroke : false
		};

		var c = $('#en');
		var ct = c.get(0).getContext('2d');
		
		var enchart = new Chart(ct).Doughnut(endata, enoptions);
	});

});

</script>
</body>
</html>