<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>文章列表</title>

    <!-- Bootstrap -->
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/liangblog/Public/bootstrap/css/bootstrap.min.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
    <link href="/liangblog/Public/bootstrap/css/blog-home.css" rel="stylesheet">


    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <link href="http://cdn.bootcss.com/toastr.js/latest/toastr.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/toastr.js/latest/toastr.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="/liangblog/Public/bootstrap/js/bootstrap.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="stylesheet" type="text/css" href="/liangblog/Public/highlightJS\styles\atelier-cave.dark.css">
<script type="text/javascript" src="/liangblog/Public/Js/showArticle/readmore.js"></script>
<script type="text/javascript" src="/liangblog/Public/Js/showArticle/showArticle.js"></script>
<script type="text/javascript" src="/liangblog/Public/goup/goup.js"></script>
<script type="text/javascript">
  var registerurl = "<?php echo U('Home/login/register');?>";
  var loginurl = "<?php echo U('Home/login/login');?>";
  var logouturl = "<?php echo U('Home/login/logout');?>";
  var goup = "/liangblog/Public/image/nav/up.png";
</script>
<script type="text/javascript" src="/liangblog/Public/Js/nav.js"></script>
<link rel="stylesheet" type="text/css" href="/liangblog/Public/goup/goup.css">

</head>
<!--login model -->

<body>

<div class="actGotop"><image src="/liangblog/Public/image/nav/up.png" id="Top"></image></div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">登陆</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="account">账户</label> 
          <input type="text" name="account" class="form-control" id="login_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="login_password">密码</label>
          <input type="password" name="password" class="form-control" id="login_password" placeholder="密码">
        </div>

        <div class="form-group">
          <label for="login_code">验证码</label>
          <input type="text" name="password" id="login_code" class="form-control" placeholder="验证码">
        </div>
        <div class="form-group">
        <image src="<?php echo U('Home/login/verifyCode');?>" id="verifyCode">
        </div>        
        <div class="form-group">
          <label>
            <input type="checkbox" name="auto" id="auto_login" value="1"> 自动登录
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#register">没有账号？点击注册</a></div>
        <button type="button" id="btn_login" class="btn btn-success" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;&nbsp;登陆</button>
      </div>
    </div>
  </div>
</div>

<!--register model -->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">注册</h4>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="register_account">账户</label>
          <input type="text" name="account" class="form-control" id="register_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="register_password">密码</label>
          <input type="password" name="password" class="form-control" id="register_password" placeholder="密码">
        </div>
        <div class="form-group">
          <label for="register_rpassword">重复密码</label>
          <input type="password" name="rpassword" class="form-control" id="register_rpassword" placeholder="重复密码">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default right" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <button type="button" id="btn_register" class="btn btn-primary" data-dismiss="modal"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;注册</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#login">已有账号？点击登陆</a></div>
      </div>
    </div>
  </div>
</div> 
 
<!--nav -->
<div class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">liangblog</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo U('Home/Article/showArticle');?>">博客</a></li>
                <li><a href="http://resume.qmail.com/liang.w.t/351hjrDgthw">简历</a></li>
                <li><a href="<?php echo U('Home/About/about');?>">关于</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!isset($_SESSION['uid'])): ?><li><a href="#" data-toggle="modal" data-target="#register">注册</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login">登陆</a></li>
                <?php else: ?>
                    <a class="navbar-brand personPhoto" href="#">
                      <img class="media-object" src="http://placehold.it/64x64" alt="" style="width: 30px;height: 30px;border-radius:50%">
                    </a>

                    <p class="navbar-text"><?php echo (session('username')); ?></p>

                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">个人中心<strong class="caret"></strong></a>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="<?php echo U('Article/writeArticle');?>">发布博客</a>
                        </li>
                        <li>
                          <a href="<?php echo U('user/editBasic');?>">修改个人信息</a>
                        </li>
                        <li>
                          <a href="#">消息中心</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                          <a id="logout" href="#">退出登录</a>
                        </li>
                      </ul>
                    </li><?php endif; ?>
            </ul>
        </div>  
    </div>    
</div>







    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-9 showArticle">
                <?php if(is_array($lists)): foreach($lists as $key=>$list): ?><!-- First Blog Post -->
                    <h2>
                        <a href="<?php echo U('Article/detailArticle');?>?id=<?php echo ($list["id"]); ?>"><?php echo ($list["title"]); ?></a>
                </h2>
                <p><span class="glyphicon glyphicon-time"></span><?php echo (date("F d,Y  ",strtotime($list["create_time"]))); ?> by <a href="<?php echo U('Resume/resume');?>?id=<?php echo ($list["uid"]); ?>"><?php echo ($list["username"]); ?></a></p>
                <article>
                    <p class="showArticle_article"><?php echo (mb_substr(strip_tags(htmlspecialchars_decode($list["content"])),0,600)); ?></p>
                </article>
                <hr><?php endforeach; endif; ?>
            </div>
            <!-- Pager -->
            <!-- Blog Sidebar Widgets Column -->
<div class="col-md-3">

    <!-- Blog Categories Well -->
    <div class="well">
        <h4>Blog Categories</h4>
        <hr/>
        <div class="row">
            <div class="col-lg-12">
                <ul class="list-unstyled">
                    <?php if(is_array($classificationL)): foreach($classificationL as $key=>$v): if($v["classification"] != null): ?><li><a href="#"><?php echo ($v["classification"]); ?></a>&nbsp;<span class="badge"><?php echo ($v["classification_num"]); ?></span></li>
                            <hr/><?php endif; endforeach; endif; ?>
                </ul>
                <h4>Side Widget Well</h4>
                <hr/>
                <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.
                </p>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>

</div>
<!-- /.blog-sidebar -->
        </div>
        <!-- /.row -->
        <div class="row">

                <nav>
                    <ul class="pagination">
                        <?php echo ($page); ?>
                    </ul>
                </nav>

        </div>
    </div>
    <!-- /.container -->
</body>
</html>