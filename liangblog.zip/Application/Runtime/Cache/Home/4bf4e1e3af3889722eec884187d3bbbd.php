<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>关于</title>

    <!-- Bootstrap -->
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/liangblog/Public/bootstrap/css/bootstrap.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
 


    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <link href="http://cdn.bootcss.com/toastr.js/latest/toastr.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/toastr.js/latest/toastr.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="/liangblog/Public/bootstrap/js/bootstrap.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="stylesheet" href="/liangblog/Public/css/about/css/hero-slider-style.css">
<link rel="stylesheet" href="/liangblog/Public/css/about/css/templatemo-style.css">
<script type="text/javascript" src="/liangblog/Public/JS/about/about.js"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	  <![endif]-->
<script type="text/javascript">
  var registerurl = "<?php echo U('login/register');?>";
  var loginurl = "<?php echo U('login/login');?>";
  var logouturl = "<?php echo U('login/logout');?>";
</script>
<script type="text/javascript" src="/liangblog/Public/Js/nav.js"></script>
<style type="text/css">
.actGotop{
    position:fixed; 
    _position:absolute; 
    bottom:10px; 
    right:90px; 
    display:none;
}
#Top{
    width:70px; 
    height:61px; 
}
.top_text{
  text-align: center;
}
</style>
<script type="text/javascript">
$(function(){ 
  $(window).scroll(function() {   
    if($(window).scrollTop() >= 100){
      $('.actGotop').fadeIn(300); 
    }else{    
      $('.actGotop').fadeOut(300);    
    }  
  });
  $('.actGotop').click(function(){$('html,body').animate({scrollTop: '0px'}, 800);}); 
});
</script>

</head>
<!--login model -->

<body>

<div class="actGotop"><image src="/liangblog/Public/image/nav/up.png" id="Top"><p class="top_text">返回顶部</p></image></div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">登陆</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="account">账户</label> 
          <input type="text" name="account" class="form-control" id="login_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="login_password">密码</label>
          <input type="password" name="password" class="form-control" id="login_password" placeholder="密码">
        </div>
        <br/>
        <div class="form-group">
          <label>
            <input type="checkbox" name="auto" id="auto_login" value="1"> 自动登录
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#register">没有账号？点击注册</a></div>
        <button type="button" id="btn_login" class="btn btn-success" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;&nbsp;登陆</button>
      </div>
    </div>
  </div>
</div>

<!--register model -->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">注册</h4>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="register_account">账户</label>
          <input type="text" name="account" class="form-control" id="register_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="register_password">密码</label>
          <input type="password" name="password" class="form-control" id="register_password" placeholder="密码">
        </div>
        <div class="form-group">
          <label for="register_rpassword">重复密码</label>
          <input type="password" name="rpassword" class="form-control" id="register_rpassword" placeholder="重复密码">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default right" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <button type="button" id="btn_register" class="btn btn-primary" data-dismiss="modal"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;注册</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#login">已有账号？点击登陆</a></div>
      </div>
    </div>
  </div>
</div>

<!--nav -->
<div class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo U('Index/index');?>">liangblog</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo U('Article/showArticle');?>">博客</a></li>
                <li><a href="<?php echo U('resume/resume');?>">简历</a></li>
                <li><a href="<?php echo U('About/about');?>">关于</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!isset($_SESSION['uid'])): ?><li><a href="#" data-toggle="modal" data-target="#register">注册</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login">登陆</a></li>
                <?php else: ?>

                    <p class="navbar-text"><?php echo (session('username')); ?></p>

                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">个人中心<strong class="caret"></strong></a>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="<?php echo U('Article/writeArticle');?>">发布博客</a>
                        </li>
                        <li>
                          <a href="<?php echo U('user/editBasic');?>">修改个人信息</a>
                        </li>
                        <li>
                          <a href="#">消息中心</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                          <a id="logout" href="#">退出登录</a>
                        </li>
                      </ul>
                    </li><?php endif; ?>
            </ul>
        </div>  
    </div>    
</div>






<div class="container">
  	<div class="page-header version" id="banner">

  	<?php if(is_array($versionL)): foreach($versionL as $key=>$version): ?><div class="row tm-media-row">
			<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2" id="icon">
			<span class="glyphicon glyphicon-calendar"></span>&nbsp;<?php echo (date('Y/d/m',$version["modify_time"])); ?>
			</div>
			<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8" id="vcontent">
				<div class="tm-media-text-container">
					<h3 class="tm-media-title tm-gray-text">
						V <?php echo ($version["version"]); ?>
					</h3>
					<p class="tm-media-description tm-gray-text-2">
						<?php echo (htmlspecialchars_decode($version["content"])); ?>
					</p>    
				</div>                    
			</div>
		</div><?php endforeach; endif; ?>

	</div>
</div>
	
	<!-- Contact section -->

	<!-- Contact section -->
	<section class="tm-bg-purple tm-section">
		<div class="container-fluid tm-section-5-inner">
			<div class="row">
				<div class="col-xs-12 tm-text-white text-xs-center">
					<h2 class="tm-section-3-title">Contact Us</h2>
					<p class="tm-section-3-description">This is my first web product. Very gald to receive your advice if your have some good idea.</p>
				</div>
			</div>
			<div class="row">
				<form action="index.html" method="post" class="tm-contact-form">
					
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
						<div class="form-group">
							<input type="text" id="contact_name" name="contact_name" class="form-control" placeholder="Name" required/>
						</div>
						<div class="form-group">
							<input type="email" id="contact_email" name="contact_email" class="form-control" placeholder="Email" required/>
						</div>
						<div class="form-group">
							<input type="text" id="contact_subject" name="contact_subject" class="form-control" placeholder="Subject" required/>
						</div>    
					</div>

					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
						<div class="form-group">
							<textarea id="contact_message" name="contact_message" class="form-control" rows="6" placeholder="Your message" required></textarea>
						</div>    
					</div>

					<div class="col-xs-12">
						<button type="submit" class="cd-btn pull-xs-right">Send it</button>                              
					</div>
				</form>  
			</div>

<!-- 			<div class="row">
				<div class="col-xs-12 text-xs-center">
					<div class="tm-social-icons-container">
						<a href="#" class="tm-social-icon-link"><i class="fa fa-facebook tm-social-icon"></i></a>
						<a href="#" class="tm-social-icon-link"><i class="fa fa-google-plus tm-social-icon"></i></a>
						<a href="#" class="tm-social-icon-link"><i class="fa fa-twitter tm-social-icon"></i></a>
						<a href="#" class="tm-social-icon-link"><i class="fa fa-behance tm-social-icon"></i></a>
						<a href="#" class="tm-social-icon-link"><i class="fa fa-linkedin tm-social-icon"></i></a>
					</div>
				</div>                    
			</div> -->
			<div class="row">
				<footer class="col-xs-12 text-xs-center">
					<p class="tm-text-white tm-copyright-text"><a target="_blank" href="https://my.oschina.net/liangwt/blog">Copyright &copy; 2016.Company name All rights reserved.</a></p>
				</footer>
			</div>
		</div>
	</section>

</div>
	<script src="/liangblog/Public/js/about/tether.min.js"></script> <!-- Tether for Bootstrap (http://stackoverflow.com/questions/34567939/how-to-fix-the-error-error-bootstrap-tooltips-require-tether-http-github-h) --> 
	<script src="/liangblog/Public/js/about/hero-slider-script.js"></script>            <!-- Hero slider (https://codyhouse.co/gem/hero-slider/) -->
	<script src="/liangblog/Public/js/about/jquery.touchSwipe.min.js"></script>         
<script>     
   
		$(document).ready(function(){

			/* Auto play bootstrap carousel 
			* http://stackoverflow.com/questions/13525258/twitter-bootstrap-carousel-autoplay-on-load
			-----------------------------------------------------------------------------------------*/                
			$('.carousel').carousel({
			  interval: 3000
			})

			/* Enable swiping carousel for tablets and mobile
			 * http://lazcreative.com/blog/adding-swipe-support-to-bootstrap-carousel-3-0/
			 ---------------------------------------------------------------------------------*/
			if($(window).width() <= 991) {
				$(".carousel-inner").swipe( {
					//Generic swipe handler for all directions
					swipeLeft:function(event, direction, distance, duration, fingerCount) {
						$(this).parent().carousel('next'); 
					},
					swipeRight: function() {
						$(this).parent().carousel('prev'); 
					},
					//Default is 75px, set to 0 for demo so any distance triggers swipe
					threshold:0
				});
			}  

			/* Handle window resize */
			$(window).resize(function(){
				if($(window).width() <= 991) {
					$(".carousel-inner").swipe( {
						//Generic swipe handler for all directions
						swipeLeft:function(event, direction, distance, duration, fingerCount) {
							$(this).parent().carousel('next'); 
						},
						swipeRight: function() {
							$(this).parent().carousel('prev'); 
						},
						//Default is 75px, set to 0 for demo so any distance triggers swipe
						threshold:0
					});
				 }
			});                             
		});

	</script>      
</body>
</html>