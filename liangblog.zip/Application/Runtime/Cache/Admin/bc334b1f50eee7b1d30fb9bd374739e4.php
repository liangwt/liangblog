<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>[title]</title>

    <!-- Bootstrap -->
    <!-- 新 Bootstrap 核心 CSS 文件 -->
    <link rel="stylesheet" href="/liangblog/Public/bootstrap/css/bootstrap.min.css">

    <!-- 可选的Bootstrap主题文件（一般不用引入） -->
    <link href="/liangblog/Public/bootstrap/css/blog-home.css" rel="stylesheet">


    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="http://cdn.bootcss.com/jquery/1.11.1/jquery.min.js"></script>
    <link href="http://cdn.bootcss.com/toastr.js/latest/toastr.css" rel="stylesheet">
    <script src="http://cdn.bootcss.com/toastr.js/latest/toastr.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="/liangblog/Public/bootstrap/js/bootstrap.js"></script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
<link rel="stylesheet" type="text/css" href="/liangblog/Public/wangEditor/css/wangEditor.min.css">
<link rel="stylesheet" type="text/css" href="/liangblog/Public/datetimepicker/bootstrap-datetimepicker.css">
<script src="/liangblog/Public/wangEditor/js/wangEditor.js"></script>
<script type="text/javascript" src="/liangblog/Public/datetimepicker/Moment.js"></script>
<script type="text/javascript" src="/liangblog/Public/datetimepicker/moment-with-locales.js"></script>
<script type="text/javascript" src="/liangblog/Public/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
    $(function(){
        //多功能编辑框
        var editor = new wangEditor('content');
        editor.config.menus = [
            'bold',
            'underline',
            'italic',
            'strikethrough',
            'forecolor',
            'bgcolor',
            '|',
            'head',
            'unorderlist',
            'orderlist',
            '|',
            'undo',
            'redo',
            'fullscreen'
        ];
        editor.create();
        //时间选择器
        $("#PubDate").datetimepicker({
            format:"YYYY/MM/DD"
        });
    })
</script>
<script type="text/javascript">
  var registerurl = "<?php echo U('login/register');?>";
  var loginurl = "<?php echo U('login/login');?>";
  var logouturl = "<?php echo U('login/logout');?>";
  var goup = "/liangblog/Public/image/nav/up.png";
</script>
<script type="text/javascript" src="/liangblog/Public/Js/nav.js"></script>
<link rel="stylesheet" type="text/css" href="/liangblog/Public/goup/goup.css">

</head>
<!--login model -->

<body>

<div class="actGotop"><image src="/liangblog/Public/image/nav/up.png" id="Top"></image></div>

<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">登陆</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="account">账户</label> 
          <input type="text" name="account" class="form-control" id="login_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="login_password">密码</label>
          <input type="password" name="password" class="form-control" id="login_password" placeholder="密码">
        </div>

        <div class="form-group">
          <label for="login_code">验证码</label>
          <input type="text" name="password" id="login_code" class="form-control" placeholder="验证码">
        </div>
        <div class="form-group">
        <image src="<?php echo U('login/verifyCode');?>" id="verifyCode">
        </div>        
        <div class="form-group">
          <label>
            <input type="checkbox" name="auto" id="auto_login" value="1"> 自动登录
          </label>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#register">没有账号？点击注册</a></div>
        <button type="button" id="btn_login" class="btn btn-success" data-dismiss="modal"><span class="glyphicon glyphicon-floppy-disk" aria-hidden="true"></span>&nbsp;&nbsp;登陆</button>
      </div>
    </div>
  </div>
</div>

<!--register model -->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel">注册</h4>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="register_account">账户</label>
          <input type="text" name="account" class="form-control" id="register_account" placeholder="账户">
        </div>
        <div class="form-group">
          <label for="register_password">密码</label>
          <input type="password" name="password" class="form-control" id="register_password" placeholder="密码">
        </div>
        <div class="form-group">
          <label for="register_rpassword">重复密码</label>
          <input type="password" name="rpassword" class="form-control" id="register_rpassword" placeholder="重复密码">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default right" data-dismiss="modal"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span>&nbsp;&nbsp;关闭</button>
        <button type="button" id="btn_register" class="btn btn-primary" data-dismiss="modal"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;注册</button>
        <div id="btn_submit" class="pull-left" data-dismiss="modal"><a href="#" data-toggle="modal" data-target="#login">已有账号？点击登陆</a></div>
      </div>
    </div>
  </div>
</div> 
 
<!--nav -->
<div class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo U('Home/Index/index');?>">liangblog</a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li><a href="<?php echo U('Home/Article/showArticle');?>">博客</a></li>
                <li><a href="http://resume.qmail.com/liang.w.t/351hjrDgthw">简历</a></li>
                <li><a href="<?php echo U('Home/About/about');?>">关于</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(!isset($_SESSION['uid'])): ?><li><a href="#" data-toggle="modal" data-target="#register">注册</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#login">登陆</a></li>
                <?php else: ?>
                    <a class="navbar-brand personPhoto" href="#">
                      <img class="media-object" src="http://placehold.it/64x64" alt="" style="width: 30px;height: 30px;border-radius:50%">
                    </a>

                    <p class="navbar-text"><?php echo (session('username')); ?></p>

                    <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">个人中心<strong class="caret"></strong></a>
                      <ul class="dropdown-menu" role="menu">
                        <li>
                          <a href="<?php echo U('Article/writeArticle');?>">发布博客</a>
                        </li>
                        <li>
                          <a href="<?php echo U('user/editBasic');?>">修改个人信息</a>
                        </li>
                        <li>
                          <a href="#">消息中心</a>
                        </li>
                        <li class="divider">
                        </li>
                        <li>
                          <a id="logout" href="#">退出登录</a>
                        </li>
                      </ul>
                    </li><?php endif; ?>
            </ul>
        </div>  
    </div>    
</div>







<!--main -->
<div class="container">
    <div class="row">
        <div class="col-sm-5 col-sm-offset-5">
            <h3>New Version Publish</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
            <form class="form-horizontal" role="form" action="<?php echo U('Admin/Publish/post');?>" method="POST">
                <div class="form-group">
                    <label for="version" class="col-sm-2 control-label">version</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="version" name="version" placeholder="version">
                    </div>
                </div>
                <div class="form-group">
                    <label for="PubDate" class="col-sm-2 control-label">Date</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="PubDate" name="PubDate" placeholder="PubDate">
                    </div>
                </div>
                <div class="form-group">
                    <label for="content" class="col-sm-2 control-label">content</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" rows="8" id="content" name="content"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" class="btn btn-default">Publish</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>