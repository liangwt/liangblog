<?php
namespace Home\Controller;
use Think\Controller;

class ResumeController extends Controller{
	public function resume(){
		$this -> show();
	}
}